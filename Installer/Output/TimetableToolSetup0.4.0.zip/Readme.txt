TimetableTool

TimetableTool is a toolkit to help you to design timetables for transportation simulators. The tool is NOT suitable to design timetables for real world application and should not be used for this purpose.
This tool is NOT free, if you use it on a regular basis, you are supposed to donate to the author:

Euro 5 for private non-commercial use
Euro 25 per user per year for professional use.

Check out http:/www.hollandhiking.nl/trainsimulator for other tools and documentation for TSW and TrainSimulator.

Installation instructions:
- You need a Windows 10 PC with the x64 architecture to run.
- It is recommended to uninstall te old version before installing the new version.
- If did not create any valuable data, you may delete the active database immediately after installing the tool. See the manual on how to do that.
- Use the installer to install
- Read the manual, which you can find in your Documents folder in the folder TimetableTool.
The tool comes with two demo timetables.

See the manual for details.

Version history:

Version 0.4.0:
Timetable graph replaced by Scottplot technology, allowing to zoom and scroll through the timetable
User settings created, including screen and storage in registry
Added configuration tables for Service Class and Time Event types
Some bug fixes

Version 0.3.0:
Bug fixes
Added new report for arrival/departure timetable
Makes viewing reports more smooth, now using a dedicated screen

Version 0.2.1:
Installer update

Version 0.2.0:
Backup and restore of databases
Import and export of routes at database level
Delete buttons now working
Database version system

Version 0.1.0:
First public alpha version. This version is intended for review and feedback purposes only.