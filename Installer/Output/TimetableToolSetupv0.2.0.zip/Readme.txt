TimetableTool

TimetableTool is a toolkit to help you to design timetables for transportation simulators. The tool is NOT suitable to design timetables for real world application and should not nbe used for this purpose.
This tool is NOT free, if you use it on a regular basis, you are supposed to donate to the author:

Euro 5 for private non-commercial use
Euro 25 per user per year for professional use.

Check out http:/www.hollandhiking.nl/trainsimulator for other tools and documentation for TSW and TrainSimulator.

Installation instructions:
- It is recommended to uninstall te old version before installing the new version.
- If did not create any valuable data, you may delete the active database immediately after installing the tool. See the manual on how to do that.
- Use the installer to install
- Read the manual, which you can find in your Documents folder in the folder TimetableTool.
The tool comes with two demo timetables.

See the manual for details.

Version history:

Version 0.2.0:
Backup and restore of databases
Import and export of routes at database level
Delete buttons now working
Database version system

Version 0.1.0:
First public alpha version. This version is intended for review and feedback purposes only.